var express = require('express');

var app = express();

var port = 5000;

app.get('/', function(req, res) {
    res.sendFile('index.html');
});

app.listen(port, function(err) {
    console.log('running of port:' + port);
})